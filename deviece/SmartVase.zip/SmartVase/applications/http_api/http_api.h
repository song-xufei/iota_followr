#ifndef __HTTP_API_H__
#define __HTTP_API_H__

typedef struct res_info
{
    int res;
    char *msg;
} res_info_t;

#endif /* __HTTP_API_H__ */
