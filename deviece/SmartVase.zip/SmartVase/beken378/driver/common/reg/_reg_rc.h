#ifndef __REG_RC_H_
#define __REG_RC_H_

#define REG_RC_SIZE           428

#define REG_RC_BASE_ADDR      0x01050000


#endif // __REG_RC_H_

