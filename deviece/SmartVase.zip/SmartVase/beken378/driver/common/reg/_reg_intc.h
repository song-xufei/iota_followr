#ifndef __REG_INTC_H_
#define __REG_INTC_H_

#define REG_INTC_SIZE      68

#define REG_INTC_BASE_ADDR 0x10910000


#endif // __REG_INTC_H_

