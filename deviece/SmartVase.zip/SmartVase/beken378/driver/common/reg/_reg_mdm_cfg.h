#ifndef __REG_MDM_CFG_H_
#define __REG_MDM_CFG_H_

#define REG_MDM_CFG_SIZE            152

#define REG_MDM_CFG_BASE_ADDR       0x01000000


#endif // __REG_MDM_CFG_H_

