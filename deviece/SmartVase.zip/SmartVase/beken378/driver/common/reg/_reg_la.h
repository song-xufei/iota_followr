#ifndef __REG_LA_H_
#define __REG_LA_H_

#define REG_LA_SIZE 64

#define REG_LA_OFFSET 0x00800000

#define REG_LA_BASE_ADDR 0x10E00000


#endif // __REG_LA_H_

