#ifndef __REG_MDM_STAT_H_
#define __REG_MDM_STAT_H_

#define REG_MDM_STAT_SIZE 108

#define REG_MDM_STAT_BASE_ADDR 0x01000000


#endif // __REG_MDM_STAT_H_

